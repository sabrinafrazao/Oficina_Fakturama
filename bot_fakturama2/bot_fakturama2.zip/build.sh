#!/bin/bash

zip -r "bot_fakturama2.zip" * -x "bot_fakturama2.zip"